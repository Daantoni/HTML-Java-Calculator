let result = document.getElementById('result');
let history = document.getElementById('history');
let operation = '';

function appendNumber(number) {
  operation += number;
  result.value = operation;
}

function appendOperator(operator) {
  operation += operator;
  result.value = operation;
}

function clearResult() {
  operation = '';
  result.value = '';
}

function calculate() {
  try {
    const answer = eval(operation);
    history.innerHTML += `<div>${operation} = ${answer}</div>`;
    clearResult();
  } catch (error) {
    alert('Error');
  }
}